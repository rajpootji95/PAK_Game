import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:pak_games/Home%20Screen/Home%20Widget/home_widget.dart';
import 'package:pak_games/Utils/colors.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:http/http.dart'as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../Api Services/api_end_points.dart';
import '../Home Screen/homeScreen.dart';

class VerifyScreen extends StatefulWidget {
  String? mobile,name,email,password,countryCode;
    int? otp;
    bool? isTrue;
   VerifyScreen({super.key,this.mobile,this.otp,this.name,this.email,this.password,this.isTrue,this.countryCode});

  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  bool isLoading = false;
  String? newPin;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Column(
        children: [
          const SizedBox(height: 25,),
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(left: 10, right: 20),
              child: Row(

                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                          color: AppColor.white,

                          borderRadius: BorderRadius.circular(100)
                      ),
                      child:  const Center(child: Icon(Icons.arrow_back,color: AppColor.black,)),
                    ),
                  ),

                  const Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: Center(child: Text("Verification",
                        style: TextStyle(
                            color: AppColor.black, fontSize: 18,fontWeight: FontWeight.bold),)),
                    ),
                  ),

                ],
              ),
            ),
          ),
          Expanded(
            flex: 14,
            child: Container(
              decoration: const BoxDecoration(
                // color: backGround,
                  borderRadius: BorderRadius.only(topRight: Radius.circular(50))
              ),
              child:
              SingleChildScrollView(
                physics: const NeverScrollableScrollPhysics(),
                child: SizedBox(
                  height: MediaQuery
                      .of(context)
                      .size
                      .height,

                  child: Padding(
                    padding: const EdgeInsets.only(
                        right: 20, left: 20, top: 50),
                    child: Column(
                      children: [

                        const Text("Code has sent to",
                          style: TextStyle(color: Colors.black),),
                        Text("${widget.countryCode}${widget.mobile.toString()}", style: const TextStyle(
                            color: Colors.black, fontWeight: FontWeight.bold),),
                        Text("OTP: ${widget.otp.toString()}", style: const TextStyle(
                            color: Colors.black, fontWeight: FontWeight.bold),),
                        const SizedBox(height: 50,),
                        PinCodeTextField(
                          keyboardType: TextInputType.phone,
                          onChanged: (value) {
                            widget.otp = int.parse(value);
                            newPin = value.toString();
                            print("${newPin}------------${widget.otp}");

                          },
                          textStyle: const TextStyle(color: Colors.black),
                          pinTheme: PinTheme(
                            shape: PinCodeFieldShape.box,
                            borderRadius: BorderRadius.circular(10),
                            activeColor: AppColor.pinkLight,
                            inactiveColor: AppColor.pinkLight,
                            selectedColor: AppColor.pinkLight,
                            fieldHeight: 60,
                            fieldWidth: 60,
                            selectedFillColor: AppColor.pinkLight,
                            inactiveFillColor: AppColor.pinkLight,
                            activeFillColor: AppColor.pinkLight,
                          ),
                          //pinBoxRadius:20,
                          appContext: context,
                          length: 4,
                        ),

                        const SizedBox(height: 20,),
                        const Text("Haven't received the verification code?",
                          style: TextStyle(
                              color: Colors.black54, fontSize: 16),),
                        InkWell(onTap: () {
                         // resendOtp();
                        },
                            child: const Text("Resend", style: TextStyle(fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),)),
                        const SizedBox(height: 50,),
                        // Obx(() => Padding(padding: const EdgeInsets.only(left: 25, right: 25), child: controller.isLoading.value ? const Center(child: CircularProgressIndicator(),) :
                        //
                        // )

                    InkWell(
                      onTap: () async {
                        setState(() {
                          isLoading = true;
                        });

                        try {
                          if (newPin == null) {
                            Fluttertoast.showToast(msg: "Please enter pin");
                          } else if (newPin == widget.otp) {
                            Fluttertoast.showToast(msg: "Please enter correct pin");
                          } else {
                            if(widget.isTrue == true){
                              print("loginOtpApi");
                              await  loginOtpApi();
                            }else{
                              print("verifyOtpApi");
                              await verifyOtpApi();
                            }

                            Fluttertoast.showToast(msg: "OTP Verified Successfully");
                          }
                        } catch (error) {
                          Fluttertoast.showToast(msg: "Verification failed: $error");
                        } finally {
                          setState(() {
                            isLoading = false;
                          });
                        }
                      },
                      child: Container(
                        height: 50,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: AppColor.pinkDark,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: isLoading
                            ? const Center(
                          child: CircularProgressIndicator(
                            color: AppColor.white,
                          ),
                        )
                            : const Center(
                          child: Text(
                            "Verify OTP",
                            style: TextStyle(
                              color: AppColor.white,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    )



                    ],
                    ),
                  ),
                ),
              ),

            ),
          )

        ],
      ),
    );
  }



  String? mobile;
  String? userId;
  Future<void> verifyOtpApi() async {
    setState(() {
      isLoading = true;
    });

    var headers = {
      'Cookie': 'ci_session=4ikbq9d7b4ndg65sg5tntnlq1vj2uhi0'
    };
    var request = http.MultipartRequest('POST', Uri.parse('${Endpoints.baseUrl}register_user'));
    request.fields.addAll({
      'mobile': widget.mobile.toString(),
      'otp': widget.otp.toString(),
      'username':widget.name.toString(),
      'email':widget.email.toString(),
      'password':widget.password.toString(),
      'country_code':widget.countryCode.toString()
    });
    print(request.fields);
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var result =  await response.stream.bytesToString();
      var finalResult  = jsonDecode(result);
      if(finalResult['error']== false){
        Fluttertoast.showToast(msg: '${finalResult['message']}',);
        setState(() {
          isLoading = false;
        });
        SharedPreferences prefs = await SharedPreferences.getInstance();

        userId = finalResult['data']['id'];
        mobile = finalResult['data']['mobile'];
        prefs.setString('userid', userId.toString());
        prefs.setString('mobile', mobile.toString());

        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const MyHomePage(title: '',)));
      }else{
        setState(() {
          isLoading = false;
        });

        Fluttertoast.showToast(msg: '${finalResult['message']}',);
      }
    }
    else {
      setState(() {
        isLoading = false;
      });

      print(response.reasonPhrase);
    }

  }
  Future<void> loginOtpApi() async {
    setState(() {
      isLoading = true;
    });

    var headers = {
      'Cookie': 'ci_session=4ikbq9d7b4ndg65sg5tntnlq1vj2uhi0'
    };
    var request = http.MultipartRequest('POST', Uri.parse('${Endpoints.baseUrl}login'));
    request.fields.addAll({
      'mobile': widget.mobile.toString(),
      'otp': widget.otp.toString(),
       'type':'mobile',
       'country_code':widget.countryCode.toString()
    });

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var result =  await response.stream.bytesToString();
      var finalResult  = jsonDecode(result);
      if(finalResult['error']== false){
        Fluttertoast.showToast(msg: '${finalResult['message']}',);
        setState(() {
          isLoading = false;
        });
        SharedPreferences prefs = await SharedPreferences.getInstance();

        userId = finalResult['data']['id'];
        mobile = finalResult['data']['mobile'];
        prefs.setString('userid', userId.toString());
        prefs.setString('mobile', mobile.toString());

        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const MyHomePage(title: '',)));
      }else{
        setState(() {
          isLoading = false;
        });

        Fluttertoast.showToast(msg: '${finalResult['message']}',);
      }
    }
    else {
      setState(() {
        isLoading = false;
      });

      print(response.reasonPhrase);
    }

  }
  
}
