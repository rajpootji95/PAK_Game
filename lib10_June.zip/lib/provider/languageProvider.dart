import 'package:flutter/material.dart';
import 'package:translator/translator.dart';

class LanguageProvider extends ChangeNotifier {
  final GoogleTranslator _translator = GoogleTranslator();
  String _selectedLanguage = 'en'; // Default language is English

  String get selectedLanguage => _selectedLanguage;


  void setLanguage(String languageCode) {
    _selectedLanguage = languageCode;

    notifyListeners();
  }

   Future<String> translate(String text) async {
      Translation translation =
          await _translator.translate(text, to: _selectedLanguage);
      return translation.text;
    }


}
 