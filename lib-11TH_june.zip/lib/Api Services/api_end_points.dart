class Endpoints {
  Endpoints._();

  // base url
  static const String baseUrl = "https://delristech-projects.in/pak_game/index.php/api/Users/";
  static const String sendOTP = "send_otp";
  static const String register = "register_user";

}