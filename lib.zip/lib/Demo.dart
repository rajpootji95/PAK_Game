
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:math';

import 'package:flutter/widgets.dart';

class Demo extends StatefulWidget {
  const Demo({super.key});

  @override
  State<Demo> createState() => _DemoState();
}

class _DemoState extends State<Demo> {
 int selectedNumberRight = Random().nextInt(6) + 1;
 int selectedNumberLeft = Random().nextInt(6) + 1;
 void generateNumberRight(){
   setState(() {
     selectedNumberRight = Random().nextInt(6) + 1;

   });
 }
 void generateNumberLeft(){
   setState(() {
     selectedNumberLeft = Random().nextInt(6) + 1;

   });
 }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title:  const Text("Dice"),),
       body: Center(
         child: Padding(
           padding:  const EdgeInsets.all(8.0),
           child: Row(
             children: [
               Expanded(
                 child: InkWell(
                     onTap: (){
                       generateNumberLeft();
                     },
                     child: Image.asset("assets/images/Dice/dice$selectedNumberLeft.png",scale: 2.3,)),
               ),
               const SizedBox(width: 10,),
               Expanded(
                 child: InkWell(
                     onTap: (){
                       generateNumberRight();
                     },
                     child: Image.asset("assets/images/Dice/dice$selectedNumberRight.png",scale: 2.3,)),
               ),
             ],
           )
         ),
       )
    );
  }
}
