import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:pak_games/Model/get_sub_category.dart';
import 'package:pak_games/Utils/colors.dart';
import 'package:pak_games/Web%20View%20Screen/web_view_screen.dart';
import 'package:pak_games/api_requests.dart';
import 'package:http/http.dart'as http;

import '../Api Services/api_end_points.dart';

class GamesView extends StatefulWidget {
  String? catId;
   GamesView({super.key,this.catId});

  @override
  State<GamesView> createState() => _GamesViewState();
}

class _GamesViewState extends State<GamesView> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSubCatApi();

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("PAK Games"),),
      body:getSubCategoryModel == null ? const Center(child: CupertinoActivityIndicator(color: AppColor.primary,)):getSubCategoryModel!.data.isEmpty ?const Center(child: Text("No Game Found!!")):
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Free Games",
                style: TextStyle(
                  color: AppColor.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 3.0,
              width: 500,
              child: GridView.builder(
                itemCount: getSubCategoryModel?.data.where((item) => item.type == "0").length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 5.0,
                  mainAxisSpacing: 5.0,
                  childAspectRatio: 1.0,
                ),
                itemBuilder: (BuildContext context, int index) {
                  var freeGames = getSubCategoryModel?.data.where((item) => item.type == "0").toList();
                  return freeGames != null ? Column(
                    children: [
                      GestureDetector(
                        onTap: () {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => WebViewScreen(
                                gameUrl: freeGames[index].url!,
                              ),
                            ),
                          );
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            height: 80,
                            width: 80,
                            child: Image.network(
                              "${freeGames[index].image}",
                              fit: BoxFit.fill,
                              errorBuilder: (context, error, stackTrace) {
                                return const Icon(Icons.error); // Placeholder for error
                              },
                            ),
                          ),
                        ),
                      ),
                      Text(
                        "${freeGames[index].title}",
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ) : const SizedBox.shrink();
                },
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Premium Games",
                style: TextStyle(
                  color: AppColor.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 3.0,
              width: 500,
              child: GridView.builder(
                itemCount: getSubCategoryModel?.data.where((item) => item.type == "1").length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 5.0,
                  mainAxisSpacing: 5.0,
                  childAspectRatio: 1.0,
                ),
                itemBuilder: (BuildContext context, int index) {
                  var paidGames = getSubCategoryModel?.data.where((item) => item.type == "1").toList();
                  return paidGames != null ? Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              duration: Duration(seconds: 1),
                              content: Text('No subscription  plan available'),
                            ),
                          );
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (context) => WebViewScreen(
                          //       gameUrl: paidGames[index].url!,
                          //     ),
                          //   ),
                          // );
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            height: 80,
                            width: 80,
                            child: Image.network(
                              "${paidGames[index].image}",
                              fit: BoxFit.fill,
                              errorBuilder: (context, error, stackTrace) {
                                return const Icon(Icons.error); // Placeholder for error
                              },
                            ),
                          ),
                        ),
                      ),
                      Text(
                        "${paidGames[index].title}",
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ) : const SizedBox.shrink();
                },
              ),
            ),
          ],
        ),
      )

    );
  }
  GetSubCategoryModel? getSubCategoryModel;
  getSubCatApi() async {
    var headers = {'Cookie': 'ci_session=rliu6p075fqkj6ogvcrtorav75j548s2'};
    var request = http.MultipartRequest(
        'POST', Uri.parse('${Endpoints.baseUrl}get_games'));
    request.fields.addAll({
      'cat_id':widget.catId.toString()
    });
    print("cat_id${widget.catId}");
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var result = await response.stream.bytesToString();
      getSubCategoryModel = GetSubCategoryModel.fromJson(jsonDecode(result));

      setState(() {});
    } else {
      print(response.reasonPhrase);
    }
  }

}
