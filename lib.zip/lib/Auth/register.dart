import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:pak_games/Auth/verify_otp_screen.dart';
import 'package:pak_games/Utils/colors.dart';
import 'package:http/http.dart' as http;
import 'package:pak_games/api_requests.dart';

import '../Api Services/api_end_points.dart';
import 'login.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  int _value = 1;
  bool isMobile = false;
  bool isSendOtp = false;
  bool isVisible = false;
  bool isLoader = false;
  bool showPassword = false;
  bool isLoading =  false;
 String? mobile;
 int? otp;

  registerApi() async {
    setState(() {
      isLoading =  true;
    });

    var headers = {
      'Cookie': 'ci_session=5nbd4rujnmj58327kb67h560njukte8i'
    };
    var request = http.MultipartRequest('POST', Uri.parse('${Endpoints.baseUrl}send_otp'));
    request.fields.addAll({
      'mobile':mobileController.text,
      'type': "1"
    });
    print("THIS IS ${request.fields}");
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var result = await response.stream.bytesToString();
      var finalResult = jsonDecode(result);
      if(finalResult['error'] == true){
        Fluttertoast.showToast(msg: "${finalResult['message']}");
      }else{
        mobile = finalResult['mobile'];
        otp = finalResult['otp'];
        Fluttertoast.showToast(msg: "${finalResult['message']}");
        Navigator.push(context, MaterialPageRoute(builder: (context)=>VerifyScreen(mobile: mobile,otp: otp,name: nameController.text,email: emailController.text,password: passwordController.text,)));
      }
      setState(() {
        isLoading =  false;
      });
    }
    else {
      setState(() {
        isLoading =  false;
      });
    print(response.reasonPhrase);
    }

  }
  @override
  Widget build(BuildContext context) {
    return  SafeArea(
      child: Scaffold(
        body: ListView(
          children: [
            SizedBox( height: MediaQuery.of(context).size.height/9.0),
            Image.asset('assets/images/pak home.png',scale: 1.5,),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              //crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 50,
                ),
              Column(children: [
                  /// email login section
                  Container(
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [

                          Material(
                            elevation: 0,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              width: MediaQuery.of(context).size.width/1.1,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: AppColor.pinkDark)
                              ),
                              height: 50,
                              child: TextField(
                                controller: nameController,
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(

                                    contentPadding:
                                    const EdgeInsets.only(top: 8),
                                    border: const OutlineInputBorder(
                                        borderSide: BorderSide.none),
                                    hintText: "Entre Name",
                                    prefixIcon: Icon(Icons.person_outline,color: AppColor.pinkDark,)
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Material(
                            elevation: 0,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              width: MediaQuery.of(context).size.width/1.1,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: AppColor.pinkDark)
                              ),
                              height: 50,
                              child: TextFormField(
                                maxLength: 10,
                                keyboardType: TextInputType.number,
                                controller: mobileController,
                                decoration:   InputDecoration(
                                  prefixIcon: Icon(Icons.call,color: AppColor.pinkDark),
                                  counterText: "",
                                  contentPadding: const EdgeInsets.only(top: 12,left: 10),
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none),
                                  hintText:  "Enter Mobile Number",
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Material(
                            elevation: 0,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              width: MediaQuery.of(context).size.width/1.1,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: AppColor.pinkDark)
                              ),
                              height: 50,
                              child: TextField(
                                controller: emailController,
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(

                                  contentPadding:
                                  const EdgeInsets.only(top: 8),
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none),
                                  hintText: "Entre Email",
                                  prefixIcon: Icon(Icons.email_outlined,color: AppColor.pinkDark,)
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Material(
                            elevation: 0,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: AppColor.pinkDark)
                              ),
                              width: MediaQuery.of(context)
                                  .size
                                  .width /
                                  1.1,
                              height: 50,
                              child: TextField(
                                obscureText: isVisible ? false : true,
                                controller: passwordController,
                                decoration: InputDecoration(
                                  contentPadding:
                                  const EdgeInsets.only(top: 8),
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none),
                                   hintText:  "Password",
                                    prefixIcon: Icon(Icons.lock_outlined,color: AppColor.pinkDark,),
                                    suffixIcon: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        isVisible ? isVisible = false : isVisible = true;
                                      });
                                    },
                                    icon: Icon(
                                      isVisible
                                          ? Icons.remove_red_eye
                                          : Icons.visibility_off,
                                      color: AppColor.pinkDark,
                                      size: 20,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),

                         SizedBox(height: 20,),
                          InkWell(
                            onTap: () {
                              // Navigator.push(context, MaterialPageRoute(builder:(context)=> MyStatefulWidget()));
                              registerApi();
                              setState(() {
                                isLoading = true;
                              });
                            },
                            child: Container(
                              height: 50,
                              width: MediaQuery.of(context)
                                  .size
                                  .width /
                                  1.1,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                borderRadius:
                                BorderRadius.circular(10),
                                color: AppColor.pinkDark,
                              ),
                              child: isLoading == true
                                  ? const Center(
                                child:
                                CircularProgressIndicator(
                                  color: Colors.white,
                                ),
                              )
                                  : const Text(
                                 "Register ",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight:
                                    FontWeight.w600,
                                    color: AppColor.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ]),

                const SizedBox(
                  height: 20,
                ),
              ],
            ),
      
          ],
        ),
          bottomSheet: Container(
            color: AppColor.white,
            child: Padding(
              padding:  const EdgeInsets.only(bottom: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't have an account?", style: const TextStyle(fontWeight: FontWeight.bold),),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
                     // Get.to(const SignUpScreen());
                    },
                    child: Text("Sign In",
                      style: TextStyle(
                          color: AppColor.pinkLight, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          )
      ),
    );
  }

}
